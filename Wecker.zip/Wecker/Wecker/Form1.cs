﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Wecker
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        int stunde, minute, sekunde;
        string alarmStunde, AlarmMinute;

        private void button1_Click(object sender, EventArgs e)
        {
            alarmStunde = comboBox1.Text;
            AlarmMinute = comboBox2.Text;
        }

        private void menuToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
        

        private void fertigToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void vonToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Von Elias Gössi");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            sekunde = DateTime.Now.Second;
            minute = DateTime.Now.Minute;
            stunde = DateTime.Now.Hour;
            label4.Text = stunde.ToString();
            label2.Text = minute.ToString();
            label3.Text = sekunde.ToString();
            Ring_Alarm();
        }

        void Ring_Alarm()
        {
            if(alarmStunde==stunde.ToString() && AlarmMinute== minute.ToString()&& sekunde.ToString()== "0")
            {
                axWindowsMediaPlayer1.URL = "C:\\Users\\elias\\Desktop\\Sketschers.mp4";
            }

            
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            timer1.Start();
            for(int i= 0; i<24; i++)
            {
                comboBox1.Items.Add(i);
            }

            for (int m = 0; m < 60; m++)
            {
                comboBox2.Items.Add(m);
            }
            Console.Read();
        }
    }
}
